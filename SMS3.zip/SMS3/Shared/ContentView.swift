//
//  ContentView.swift
//  Shared
//
//  Created by Shubham Kulthe on 08/06/21.
//

import SwiftUI
import RealityKit

struct ContentView: View {
    
    @EnvironmentObject var placementSettings : PlacementSettings
    @State private var isControlVisible : Bool = true
    @State private var showBrowse : Bool = false
    @State private var showSettings : Bool = false
    
    
    var body: some View {
        ZStack(alignment: .bottom){
            ARViewContainer()
            
            if self.placementSettings.selectedModel == nil {
                ControlView(isControlVisible: $isControlVisible, showBrowse: $showBrowse ,showSettings : $showSettings )
            }else{
                PlacementView()
            }
            
        }
        .edgesIgnoringSafeArea(.all)
            
    }
}


struct ARViewContainer :
    UIViewRepresentable {
    
    @EnvironmentObject var placementSettings : PlacementSettings
    @EnvironmentObject var sessionSettings : SessionSettings
    
    func makeUIView(context: Context) ->
    CustomeARView {
        let arView = CustomeARView(frame: .zero, sessionSettings: sessionSettings)
        
//        subscriber to showevents
        self.placementSettings.sceneObserver  = arView.scene.subscribe(to: SceneEvents.Update.self, { (event) in
//            TODO: Call upadtescnces view
            self.updateScene(for: arView)
        })
        return arView
    }
    func updateUIView(_ uiView: CustomeARView, context: Context) {}
    
    //add new func in ARView
    private func updateScene(for arView: CustomeARView){
        //Only display focusEntity when the user has selected a model for placement
        arView.focusEntity?.isEnabled = self.placementSettings.selectedModel != nil

        //Add model to scene if confirmed for placement
        if let confirmedModel = self.placementSettings.confirmedModel, let modelEntity = confirmedModel.modelEntity{
            
            self.place(modelEntity, in: arView)

            self.placementSettings.confirmedModel = nil
        }
    }
    
    //after updateScene add place() function
    private func place(_ modelEntity: ModelEntity, in arView: ARView){
        //1. Clone modelEntity. This creates an identical copy of modelEntity and reference the same model. This also allows us to have multiple models of the same asset is our scene.

        let clonedEntity = modelEntity.clone(recursive: true)


        //2.Enable translation and rotation gestures.

        clonedEntity.generateCollisionShapes(recursive: true)
        arView.installGestures([.translation, .rotation], for: clonedEntity)

        //3. Created an anchorEntity and add clonedEntity to the anchorEntity.

        let anchorEntity = AnchorEntity(plane: .any)
        anchorEntity.addChild(clonedEntity)

        //4. Add the anchorEntity to the arView.scene
        arView.scene.addAnchor(anchorEntity)

        print("Added modelEntity to scene.")
    }

    
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(PlacementSettings())
            .environmentObject(SessionSettings())
        
    }
}
