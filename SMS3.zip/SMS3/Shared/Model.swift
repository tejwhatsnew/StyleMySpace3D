//
//  Model.swift
//  SMS3
//
//  Created by Shubham Kulthe on 08/06/21.

import SwiftUI
import RealityKit
import Combine

enum ModelCategory: CaseIterable{
    case table
    case chair
    case decor
    case light

    var label: String{
        get{
            switch self{
            case .table:
                return "Tables"
            case .chair:
                return "Chairs"
            case .decor:
                return "Decor"
            case .light:
                return "Lights"
            }
        }
    }
}


class Model{
    var name: String
    var category: ModelCategory
    var thumbnail: UIImage
    var modelEntity: ModelEntity?
//    var scaleCompensation: Float

    private var cancellable: AnyCancellable?


    init(name: String,category: ModelCategory, scaleCompensation: Float = 0.1){
        self.name = name
        self.category = category
        self.thumbnail = UIImage(named:name) ?? UIImage(systemName:"photo")!
//        self.scaleCompensation = scaleCompensation
    }


    func asyncLoadModelEntity(){
        let filename=self.name  + ".usdz"

        self.cancellable = ModelEntity.loadModelAsync(named:filename)
            .sink(receiveCompletion: { loadCompletion in

                switch loadCompletion{
                    case .failure(let error):print("Unable to load modelEntity for \(filename).Error: \(error.localizedDescription)")
                    case .finished:
                        break
                }
            },receiveValue: {modelEntity in
                
                self.modelEntity = modelEntity
                
//                self.modelEntity?.scale *= self.scaleCompensation

                print("modelEntity for \(self.name) has been loaded.")
            })
    }
}


struct Models{
    var all: [Model] = []

    init(){
        //Table
//        let Table = Model(name:"table", category: .table, scaleCompensation: 0.32/100)
//        let ComputerTable = Model(name:"computerTable", category: .table, scaleCompensation: 0.32/100)

        let Table = Model(name:"table", category: .table)
        let ComputerTable = Model(name:"computerTable", category: .table)
        self.all += [Table,ComputerTable]

        //Chairs
        let diningChair = Model(name:"dinning_chair", category: .chair, scaleCompensation:0.32/100)
        let eamesChairBlack = Model(name:"chair", category: .chair, scaleCompensation:0.32/100)
        let blackChair = Model(name: "chairBlack", category: .chair, scaleCompensation: 0.32/100)
        let oakChair = Model(name: "oakChair", category: .chair, scaleCompensation: 0.32/100)
        let MammothChair = Model(name: "MammothChair", category: .chair, scaleCompensation: 0.32/100)
        
//        let eamesChairBlack = Model(name:"chair", category: .chair, scaleCompensation:0.32/100)
//        let blackChair = Model(name: "chairBlack", category: .chair)
//        let oakChair = Model(name: "oakChair", category: .chair)
//        let MammothChair = Model(name: "MammothChair", category: .chair)

        self.all += [eamesChairBlack,blackChair,oakChair,MammothChair]

        //Decor
        let flower = Model(name: "flower_tulip", category: .decor, scaleCompensation: 0.32/100)
        let cupandsaucer = Model(name: "cupandsaucer", category: .decor, scaleCompensation: 0.32/100)
        let teapot = Model(name: "teapot", category: .decor, scaleCompensation: 0.32/100)
        let GrenadaCommode = Model(name: "GrenadaCommode", category: .decor, scaleCompensation: 0.32/100)
        
        
//        let flower = Model(name: "flower_tulip", category: .decor)
//        let cupandsaucer = Model(name: "cupandsaucer", category: .decor)
//        let teapot = Model(name: "teapot", category: .decor)
//        let GrenadaCommode = Model(name: "GrenadaCommode", category: .decor)
        
        self.all += [flower,cupandsaucer,teapot,GrenadaCommode]

        //Lights
        let plane = Model(name: "biplane", category: .light, scaleCompensation: 0.32/100)
        
        self.all += [plane]
        
//        chairBlack
        

    }
    func get(category : ModelCategory)-> [Model]{
        return all.filter( {$0.category == category})
    }
}
