//
//  SMS3App.swift
//  Shared
//
//  Created by Shubham Kulthe on 08/06/21.
//

import SwiftUI

@main
struct SMS3App: App {
    @StateObject var placementSettings  = PlacementSettings()
    @StateObject var sessionSettings = SessionSettings()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(placementSettings)
                .environmentObject(sessionSettings)
            
        }
    }
}
