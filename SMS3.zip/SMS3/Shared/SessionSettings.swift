//
//  SessionSettings.swift
//  SMS3
//
//  Created by Shubham Kulthe on 09/06/21.
//

import SwiftUI

class SessionSettings: ObservableObject {
    
    @Published var isPeopleOcclusionEnabled: Bool = false
    @Published var isObjectOcclusionEnabled: Bool = false
    @Published var isLidarDebugEnabled: Bool = false
    @Published var isMultiuserEnabled: Bool = false
}
